Although asked to submit one single file, due to volume of work and in order to make tasks modular so that experiments can be conducted efficiently

I seperate the work into 3 parts, with prefix to be the order to use

U might not want to run all in the 2nd file since the gradient forest fitting takes some time

